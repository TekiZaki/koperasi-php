<?php
// ajax_get_saving_details.php
session_start();
header('Content-Type: application/json');

// Basic security checks
if (!isset($_SESSION['user_id']) || !isset($_GET['member_name'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Bad Request']);
    exit();
}

require_once 'config/Database.php';
require_once 'models/Saving.php';

$database = new Database();
$db = $database->getConnection();
$saving = new Saving($db);

// Sanitize member name from GET parameter
$saving->member_name = urldecode($_GET['member_name']);

// Fetch saving details for the member
$stmt = $saving->readByMemberName();

$savings_details = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Return as JSON, even if it's an empty array
echo json_encode($savings_details);