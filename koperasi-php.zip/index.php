<?php
session_start();

// Autoload models
spl_autoload_register(function ($class_name) {
    $file = __DIR__ . '/models/' . $class_name . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});

require_once 'config/Database.php';

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$database = new Database();
$db = $database->getConnection();

$page = $_GET['page'] ?? 'dashboard';

include 'includes/header.php';

// Page routing
switch ($page) {
    case 'transactions':
        include 'pages/transactions.php';
        break;
    case 'savings':
        include 'pages/savings.php';
        break;
    case 'loans':
        include 'pages/loans.php';
        break;
    case 'infaq':
        include 'pages/infaq.php';
        break;
    case 'dashboard':
    default:
        include 'pages/dashboard.php';
        break;
}

include 'includes/footer.php';
?>