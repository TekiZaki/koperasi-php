<?php
// koperasi-php/models/Infaq.php
class Infaq {
    private $conn;
    private $table_name = "infaqs";

    public $id;
    public $infaq_date;
    public $description;
    public $donor_name;
    public $amount;
    public $type; // pemasukan, pengeluaran
    public $created_by_user_id;
    public $created_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Baca semua data infaq
    public function read() {
        $query = "SELECT id, infaq_date, description, donor_name, amount, type FROM " . $this->table_name . " ORDER BY infaq_date DESC, id DESC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }

    // Buat data infaq baru
    public function create() {
        $query = "INSERT INTO " . $this->table_name . " SET infaq_date = :infaq_date, description = :description, donor_name = :donor_name, amount = :amount, type = :type, created_by_user_id = :created_by_user_id";
        $stmt = $this->conn->prepare($query);

        // Sanitize
        $this->infaq_date = htmlspecialchars(strip_tags($this->infaq_date));
        $this->description = htmlspecialchars(strip_tags($this->description));
        $this->donor_name = htmlspecialchars(strip_tags($this->donor_name));
        $this->amount = htmlspecialchars(strip_tags($this->amount));
        $this->type = htmlspecialchars(strip_tags($this->type));
        $this->created_by_user_id = htmlspecialchars(strip_tags($this->created_by_user_id));

        // Bind values
        $stmt->bindParam(":infaq_date", $this->infaq_date);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":donor_name", $this->donor_name);
        $stmt->bindParam(":amount", $this->amount);
        $stmt->bindParam(":type", $this->type);
        $stmt->bindParam(":created_by_user_id", $this->created_by_user_id);

        if ($stmt->execute()) {
            return true;
        }
        error_log("Infaq create error: " . implode(" ", $stmt->errorInfo()));
        return false;
    }

    // Perbarui data infaq
    public function update() {
        $query = "UPDATE " . $this->table_name . " SET infaq_date = :infaq_date, description = :description, donor_name = :donor_name, amount = :amount, type = :type WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        // Sanitize and bind
        $this->infaq_date = htmlspecialchars(strip_tags($this->infaq_date));
        $this->description = htmlspecialchars(strip_tags($this->description));
        $this->donor_name = htmlspecialchars(strip_tags($this->donor_name));
        $this->amount = htmlspecialchars(strip_tags($this->amount));
        $this->type = htmlspecialchars(strip_tags($this->type));
        $this->id = htmlspecialchars(strip_tags($this->id));

        $stmt->bindParam(":infaq_date", $this->infaq_date);
        $stmt->bindParam(":description", $this->description);
        $stmt->bindParam(":donor_name", $this->donor_name);
        $stmt->bindParam(":amount", $this->amount);
        $stmt->bindParam(":type", $this->type);
        $stmt->bindParam(":id", $this->id);

        if ($stmt->execute()) {
            return true;
        }
        error_log("Infaq update error: " . implode(" ", $stmt->errorInfo()));
        return false;
    }

    // Hapus data infaq
    public function delete() {
        $query = "DELETE FROM " . $this->table_name . " WHERE id = :id";
        $stmt = $this->conn->prepare($query);

        $this->id = htmlspecialchars(strip_tags($this->id));
        $stmt->bindParam(':id', $this->id);

        if ($stmt->execute()) {
            return true;
        }
        error_log("Infaq delete error: " . implode(" ", $stmt->errorInfo()));
        return false;
    }

    // New method to read unique donor names
    public function readUniqueDonorNames() {
        $query = "SELECT DISTINCT donor_name FROM " . $this->table_name . " WHERE donor_name IS NOT NULL AND donor_name != '' ORDER BY donor_name ASC";
        $stmt = $this->conn->prepare($query);
        $stmt->execute();
        return $stmt;
    }
}
