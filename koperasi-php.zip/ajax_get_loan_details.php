<?php
// ajax_get_loan_details.php
session_start();
header('Content-Type: application/json');

// Basic security checks
if (!isset($_SESSION['user_id']) || !isset($_GET['loan_id'])) {
    http_response_code(400);
    echo json_encode(['error' => 'Bad Request']);
    exit();
}

require_once 'config/Database.php';
require_once 'models/Loan.php';

$database = new Database();
$db = $database->getConnection();
$loan = new Loan($db);

$loan->id = intval($_GET['loan_id']);

// Fetch loan details
$loan_stmt = $loan->readOne();
if ($loan_stmt->rowCount() == 0) {
    http_response_code(404);
    echo json_encode(['error' => 'Loan not found']);
    exit();
}
$loan_details = $loan_stmt->fetch(PDO::FETCH_ASSOC);

// Fetch payment history
$payments_stmt = $loan->readLoanPayments();
$payments = $payments_stmt->fetchAll(PDO::FETCH_ASSOC);

// Combine and return as JSON
echo json_encode([
    'loan' => $loan_details,
    'payments' => $payments
]);