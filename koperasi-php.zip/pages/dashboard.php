<?php
// Instantiate models to get summary data
$transactionModel = new Transaction($db);
$savingModel = new Saving($db);
$loanModel = new Loan($db);
$infaqModel = new Infaq($db);

// --- Calculate Total Kas Umum ---
$allTransactions = $transactionModel->read()->fetchAll(PDO::FETCH_ASSOC);
$totalPemasukanKas = 0;
$totalPengeluaranKas = 0;
foreach ($allTransactions as $t) {
    if ($t['type'] == 'pemasukan') {
        $totalPemasukanKas += $t['amount'];
    } else {
        $totalPengeluaranKas += $t['amount'];
    }
}
$saldoKas = $totalPemasukanKas - $totalPengeluaranKas;

// --- Calculate Total Simpanan ---
$allSavings = $savingModel->read()->fetchAll(PDO::FETCH_ASSOC);
$totalSimpanan = array_sum(array_column($allSavings, 'amount'));

// --- Calculate Total Piutang (Outstanding Loans) ---
$allLoans = $loanModel->read()->fetchAll(PDO::FETCH_ASSOC);
$totalPiutangAktif = 0;
foreach ($allLoans as $l) {
    if ($l['status'] == 'aktif') {
        $totalPiutangAktif += $l['remaining_amount'];
    }
}

// --- Calculate Total Infaq ---
$allInfaqs = $infaqModel->read()->fetchAll(PDO::FETCH_ASSOC);
$totalPemasukanInfaq = 0;
$totalPengeluaranInfaq = 0;
foreach ($allInfaqs as $i) {
    if ($i['type'] == 'pemasukan') {
        $totalPemasukanInfaq += $i['amount'];
    } else {
        $totalPengeluaranInfaq += $i['amount'];
    }
}
$saldoInfaq = $totalPemasukanInfaq - $totalPengeluaranInfaq;

// --- Get 5 Recent Activities (Combined) ---
// Note: For a large dataset, a more efficient UNION query in the model would be better.
// For simplicity here, we'll merge and sort in PHP.
$recentActivities = array_merge(
    array_slice($allTransactions, 0, 5),
    array_slice($allSavings, 0, 5),
    array_slice($allInfaqs, 0, 5)
);

// Add a 'date' key for consistent sorting
foreach($recentActivities as &$item) {
    $item['date'] = $item['transaction_date'] ?? $item['saving_date'] ?? $item['infaq_date'];
}

usort($recentActivities, function($a, $b) {
    return strtotime($b['date']) - strtotime($a['date']);
});

$recentActivities = array_slice($recentActivities, 0, 5);

?>

<div class="page-header">
    <h1>Dashboard</h1>
</div>

<div class="dashboard-summary">
    <div class="summary-card">
        <h3>Saldo Kas Umum</h3>
        <p>Rp <?php echo number_format($saldoKas, 0, ',', '.'); ?></p>
    </div>
    <div class="summary-card">
        <h3>Total Simpanan Anggota</h3>
        <p>Rp <?php echo number_format($totalSimpanan, 0, ',', '.'); ?></p>
    </div>
    <div class="summary-card">
        <h3>Piutang Aktif</h3>
        <p>Rp <?php echo number_format($totalPiutangAktif, 0, ',', '.'); ?></p>
    </div>
    <div class="summary-card">
        <h3>Saldo Kas Infaq</h3>
        <p>Rp <?php echo number_format($saldoInfaq, 0, ',', '.'); ?></p>
    </div>
</div>

<div class="card mt-4">
    <div class="card-body">
        <h3>Aktivitas Terbaru</h3>
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>Tanggal</th>
                        <th>Kategori</th>
                        <th>Deskripsi</th>
                        <th>Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($recentActivities)): ?>
                        <tr><td colspan="4" style="text-align:center;">Tidak ada aktivitas terbaru.</td></tr>
                    <?php else: ?>
                        <?php foreach($recentActivities as $activity): ?>
                        <tr>
                            <td><?php echo date("d M Y", strtotime($activity['date'])); ?></td>
                            <td>
                                <?php 
                                    if (isset($activity['transaction_date'])) echo 'Kas Umum';
                                    elseif (isset($activity['saving_date'])) echo 'Simpanan';
                                    elseif (isset($activity['infaq_date'])) echo 'Infaq';
                                ?>
                            </td>
                            <td><?php echo htmlspecialchars($activity['description']); ?></td>
                            <td class="text-right <?php echo ($activity['type'] ?? 'pemasukan') == 'pemasukan' ? 'text-success' : 'text-danger'; ?>">
                                <?php echo "Rp " . number_format($activity['amount'], 0, ',', '.'); ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>