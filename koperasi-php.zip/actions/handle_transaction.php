<?php
session_start();
require_once '../config/Database.php';
require_once '../models/Transaction.php';

// Authorization check: Must be admin or superadmin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin', 'superadmin'])) {
    header("Location: ../index.php?page=transactions&error=unauthorized");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$transaction = new Transaction($db);

$action = $_POST['action'] ?? '';

try {
    if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $transaction->transaction_date = $_POST['transaction_date'];
        $transaction->name = $_POST['name'];
        $transaction->description = $_POST['description'];
        $transaction->type = $_POST['type'];
        $transaction->amount = $_POST['amount'];
        $transaction->created_by_user_id = $_SESSION['user_id'];
        $transaction->create();
    } elseif ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $transaction->id = $_POST['id'];
        $transaction->transaction_date = $_POST['transaction_date'];
        $transaction->name = $_POST['name'];
        $transaction->description = $_POST['description'];
        $transaction->type = $_POST['type'];
        $transaction->amount = $_POST['amount'];
        $transaction->update();
    } elseif ($action === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $transaction->id = $_POST['id'];
        $transaction->delete();
    }
} catch (Exception $e) {
    // Optional: Log error
    // error_log("Transaction action failed: " . $e->getMessage());
    header("Location: ../index.php?page=transactions&status=error");
    exit();
}

header("Location: ../index.php?page=transactions&status=success");
exit();