<?php
session_start();
require_once '../config/Database.php';
require_once '../models/Saving.php';

// Authorization check: Must be admin or superadmin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin', 'superadmin'])) {
    header("Location: ../index.php?page=savings&error=unauthorized");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$saving = new Saving($db);

$action = $_POST['action'] ?? '';

try {
    if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $saving->saving_date = $_POST['saving_date'];
        $saving->member_name = $_POST['member_name'];
        $saving->saving_type = $_POST['saving_type'];
        $saving->amount = $_POST['amount'];
        $saving->description = $_POST['description'];
        $saving->created_by_user_id = $_SESSION['user_id'];
        $saving->create();
    } elseif ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $saving->id = $_POST['id'];
        $saving->saving_date = $_POST['saving_date'];
        $saving->member_name = $_POST['member_name'];
        $saving->saving_type = $_POST['saving_type'];
        $saving->amount = $_POST['amount'];
        $saving->description = $_POST['description'];
        $saving->update();
    } elseif ($action === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $saving->id = $_POST['id'];
        $saving->delete();
    }
} catch (Exception $e) {
    header("Location: ../index.php?page=savings&status=error");
    exit();
}

header("Location: ../index.php?page=savings&status=success");
exit();