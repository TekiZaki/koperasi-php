<?php
session_start();
require_once '../config/Database.php';
require_once '../models/Loan.php';

// Authorization check: Must be admin or superadmin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin', 'superadmin'])) {
    header("Location: ../index.php?page=loans&error=unauthorized");
    exit();
}

// Check if it's a POST request with the required loan_id
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_POST['loan_id'])) {
    header("Location: ../index.php?page=loans&status=error");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$loan = new Loan($db);

$loan_id = $_POST['loan_id'];

try {
    // Assign POST data to the model properties for a new payment
    $loan->id = $loan_id; // The 'id' property of the model is used for loan_id context
    $loan->payment_date = $_POST['payment_date'];
    $loan->payment_amount = $_POST['payment_amount'];
    $loan->payment_month_no = !empty($_POST['payment_month_no']) ? $_POST['payment_month_no'] : null;
    $loan->payment_description = $_POST['description'];
    $loan->created_by_user_id = $_SESSION['user_id'];

    if ($loan->addPayment()) {
        // If payment is added successfully, update the loan's main status (e.g., to 'selesai')
        $loan->updateLoanStatus($loan_id);
    } else {
        throw new Exception("Failed to add payment.");
    }

} catch (Exception $e) {
    header("Location: ../index.php?page=loans&status=error");
    exit();
}

header("Location: ../index.php?page=loans&status=success");
exit();