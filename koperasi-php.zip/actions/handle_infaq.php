<?php
session_start();
require_once '../config/Database.php';
require_once '../models/Infaq.php';

// Authorization check: Must be admin or superadmin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin', 'superadmin'])) {
    header("Location: ../index.php?page=infaq&error=unauthorized");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$infaq = new Infaq($db);

$action = $_POST['action'] ?? '';

try {
    if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $infaq->infaq_date = $_POST['infaq_date'];
        $infaq->donor_name = $_POST['donor_name'];
        $infaq->description = $_POST['description'];
        $infaq->type = $_POST['type'];
        $infaq->amount = $_POST['amount'];
        $infaq->created_by_user_id = $_SESSION['user_id'];
        $infaq->create();
    } elseif ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $infaq->id = $_POST['id'];
        $infaq->infaq_date = $_POST['infaq_date'];
        $infaq->donor_name = $_POST['donor_name'];
        $infaq->description = $_POST['description'];
        $infaq->type = $_POST['type'];
        $infaq->amount = $_POST['amount'];
        $infaq->update();
    } elseif ($action === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $infaq->id = $_POST['id'];
        $infaq->delete();
    }
} catch (Exception $e) {
    header("Location: ../index.php?page=infaq&status=error");
    exit();
}

header("Location: ../index.php?page=infaq&status=success");
exit();