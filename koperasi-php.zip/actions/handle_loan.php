<?php
session_start();
require_once '../config/Database.php';
require_once '../models/Loan.php';

// Authorization check: Must be admin or superadmin
if (!isset($_SESSION['user_id']) || !in_array($_SESSION['user_role'], ['admin', 'superadmin'])) {
    header("Location: ../index.php?page=loans&error=unauthorized");
    exit();
}

$database = new Database();
$db = $database->getConnection();
$loan = new Loan($db);

$action = $_POST['action'] ?? '';

try {
    if ($action === 'create' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $loan->loan_date = $_POST['loan_date'];
        $loan->member_name = $_POST['member_name'];
        $loan->loan_amount = $_POST['loan_amount'];
        $loan->tenor_months = $_POST['tenor_months'];
        $loan->status = 'aktif'; // New loans are always aktif
        $loan->created_by_user_id = $_SESSION['user_id'];
        $loan->create();
    } elseif ($action === 'update' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $loan->id = $_POST['id'];
        $loan->loan_date = $_POST['loan_date'];
        $loan->member_name = $_POST['member_name'];
        $loan->loan_amount = $_POST['loan_amount'];
        $loan->tenor_months = $_POST['tenor_months'];
        $loan->status = $_POST['status'];
        
        if ($loan->update()) {
            // After updating, re-check the status in case the loan amount changed
            $loan->updateLoanStatus($_POST['id']);
        }

    } elseif ($action === 'delete' && $_SERVER['REQUEST_METHOD'] === 'POST') {
        $loan->id = $_POST['id'];
        $loan->delete();
    }
} catch (Exception $e) {
    header("Location: ../index.php?page=loans&status=error");
    exit();
}

header("Location: ../index.php?page=loans&status=success");
exit();