<?php
//
// This check should be at the top of any protected page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
$user_name = $_SESSION['user_name'] ?? 'Guest';
$user_role = $_SESSION['user_role'] ?? 'user';

// Helper function to check for admin roles
function isAdmin() {
    return in_array($_SESSION['user_role'], ['admin', 'superadmin']);
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Koperasi</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body data-user-role="<?php echo htmlspecialchars($user_role); ?>">
    <div class="app-container">
        <?php include 'sidebar.php'; ?>
        <div class="main-content">
            <header class="app-header">
                <button class="menu-toggle" id="menu-toggle">
                    &#9776; <!-- Hamburger Icon -->
                </button>
                <div class="user-info">
                    <span>Selamat Datang, <strong><?php echo htmlspecialchars($user_name); ?></strong></span>
                    <a href="logout.php" class="logout-btn">Logout</a>
                </div>
            </header>
            <main class="content-body">
